package com.tienda_l.service;

import java.util.List;

import com.tienda_l.domain.Cliente;

public interface ClienteService {
    public List<Cliente> getClientes();

    public Cliente getCliente(Cliente cliente);

    public void save(Cliente cliente);

    public void delete(Cliente cliente);
}
