package com.tienda_l.service;

import java.util.List;

import com.tienda_l.domain.Categoria;

public interface CategoriaService {
    public List<Categoria> getCategorias(boolean activos);

    public Categoria getCategoria(Categoria categoria);

    public void save(Categoria categoria);

    public void delete(Categoria categoria);
}
