package com.tienda_l;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

        /*
         * @Bean
         * public UserDetailsService users() {
         * UserDetails admin = User.builder()
         * .username("Juan")
         * .password("{noop}Juan123")
         * .roles("USER", "ADMIN", "VENDEDOR")
         * .build();
         * UserDetails sales = User.builder()
         * .username("Rebeca")
         * .password("{noop}Rebeca123")
         * .roles("USER", "VENDEDOR")
         * .build();
         * UserDetails user = User.builder()
         * .username("Pedro")
         * .password("{noop}Pedro123")
         * .roles("USER")
         * .build();
         * 
         * return new InMemoryUserDetailsManager(user, sales, admin);
         * }
         */
        @Autowired
        private UserDetailsService userDetailsService;

        @Autowired
        public void configurerGlobal(AuthenticationManagerBuilder build) throws Exception {
                build.userDetailsService(userDetailsService).passwordEncoder(new BCryptPasswordEncoder());
        }

        @Bean
        public SecurityFilterChain securityFilterChain(HttpSecurity http)
                        throws Exception {
                http
                                .authorizeHttpRequests((request) -> request
                                                .requestMatchers("/",
                                                                "/index",
                                                                "/errores/**",
                                                                "/webjars/**",
                                                                "/carrito/**")
                                                .permitAll()
                                                .requestMatchers(
                                                                "/articulo/nuevo",
                                                                "/articulo/guardar",
                                                                "/articulo/modificar/**",
                                                                "/articulo/eliminar/**",
                                                                "/categoria/nuevo",
                                                                "/categoria/guardar",
                                                                "/categoria/modificar/**",
                                                                "/categoria/eliminar/**",
                                                                "/cliente/nuevo",
                                                                "/cliente/guardar",
                                                                "/cliente/modificar/**",
                                                                "/cliente/eliminar/**")
                                                .hasRole("ADMIN")
                                                .requestMatchers(
                                                                "/articulo/listado",
                                                                "/categoria/listado",
                                                                "/cliente/listado")
                                                .hasAnyRole("ADMIN", "VENDEDOR").requestMatchers("/facturar/carrito")
                                                .hasRole("USER"))
                                .formLogin((form) -> form
                                                .loginPage("/login").permitAll())
                                .logout((logout) -> logout.permitAll())
                                .exceptionHandling()
                                .accessDeniedPage("/errores/403");
                return http.build();
        }

}